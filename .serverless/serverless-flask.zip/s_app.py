import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='gpalmeri44',
    application_name='merkle-api',
    app_uid='q5lDzFGgTbs7F3lqQD',
    org_uid='5d4eeca6-b543-4ce4-81dc-0abea88e7683',
    deployment_uid='6554151a-a292-42de-b80f-c9c8286501c2',
    service_name='serverless-flask',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
